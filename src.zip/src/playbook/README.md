# Playbook: a simple llm-based ai responed tool
